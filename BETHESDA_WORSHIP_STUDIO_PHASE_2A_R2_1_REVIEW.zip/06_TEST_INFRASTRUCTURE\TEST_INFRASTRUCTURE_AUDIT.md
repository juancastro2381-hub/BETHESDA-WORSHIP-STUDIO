# BETHESDA WORSHIP STUDIO — PHASE 2A-R2.1
## TEST INFRASTRUCTURE & EXECUTION TOPOLOGY AUDIT

**Environment:** Production-identical local test harness  
**PostgreSQL Version:** 16.x / Standard PostgreSQL Engine  
**pg-boss Version:** 12.38.1  
**Runtime:** Node.js v24.12.0 / tsx v4.19.3  

---

### 1. Test Harness Categorization Matrix

| Test Suite File | Component Under Test | PostgreSQL Mode | pg-boss Mode | Storage Mode | Purpose & Guarantees |
|---|---|---|---|---|---|
| `conversion-cancellation.test.ts` | `ConversionJobService`, `ConversionWorker` | **Real PostgreSQL** | Simulated Workers on Real DB | In-Memory / DB Rows | Validates Scenarios A–I: Atomic SQL conditional update rejection, fencing tokens, terminal state immutability. Zero synthetic overwrites. |
| `conversion-audit-remediation.test.ts` | `ConversionJobService`, `ConversionWorker` | **Real PostgreSQL** | Real Queue Enqueue / Retry Claim | Real Disk FileSystem (`storage/test-audit-remediation`) | Validates fail-closed rejection, transient error propagation to pg-boss, stale job no-limbo recovery, storage reconciliation. |
| `conversion-concurrency-leases.test.ts` | `ConversionWorker`, Distributed Leases | **Real PostgreSQL** | Real pg-boss Enqueue | Real Storage Provider | Validates distributed leasing contention (only 1 winner), heartbeat renewals, stale lease reclamation, retry limit exhaustion. |
| `conversion-catalog-idempotency.test.ts` | `ConversionJobService.commitJobToCatalog` | **Real PostgreSQL** | Background DB Rows | Real Storage Provider | Validates `FOR UPDATE` pessimistic row locks, sequential idempotency, concurrent double-commit deduplication, ACID rollback. |
| `conversion-queue-lifecycle.test.ts` | `conversion-queue.ts`, `ConversionWorker` | **Real PostgreSQL** | **Real pg-boss** | Real Storage Provider | Validates pg-boss queue startup idempotency, duplicate start race prevention, clean shutdown, and persistence error on broker disconnect. |
| `conversion-security.test.ts` | Conversion HTTP API Routes | **Real PostgreSQL** | Real Queue Enqueue | Real Storage Provider | Validates Anti-IDOR (User B 403 on User A jobs), admin privilege inspection, tenant isolation, download protection. |
| `conversion-api.test.ts` | Conversion HTTP API Routes | **Real PostgreSQL** | Real Queue Enqueue | Real Storage Provider | Validates direct transpile, validation endpoint, Zero-Fabrication rejection (ChordPro->MIDI 400), deferred Phase 2B rejection. |
| `format-capabilities.test.ts` | `FormatCapabilitiesEvaluator` | Pure Logic (Unit) | N/A | Memory Buffers | Validates fail-closed detection of unknown extensions, binary control bytes, non-MusicXML XML, arbitrary non-canonical JSON. |
| `conversion-engine.test.ts` | `ConversionEngine` | Pure Logic (Unit) | N/A | Memory Strings / Buffers | Validates multi-format serialization (MusicXML, MIDI, ChordPro, Lyrics) and deferred format rejection. |
| `conversion-transformer.test.ts` | `ConversionTransformer` | Pure Logic (Unit) | N/A | Memory Payload | Validates semitone transposition, key overrides, BPM overrides, and musical range integrity. |
| `universal-ingestion-phase1b-r.test.ts` | `UniversalIngestionService` | **Real PostgreSQL** | Background Jobs | Mock Storage on Failure Test | Validates fail-safe storage failure handling (uses isolated mock for disk failure simulation while keeping DB real). |

---

### 2. Evidence of Real PostgreSQL & pg-boss Execution

1. **Authoritative PostgreSQL Connection Pool:**
   All backend tests import `db` and `pool` from `src/db/index.ts`, establishing live TCP connections to the PostgreSQL test instance (`postgresql://postgres:postgres@localhost:5432/bethesda_worship_studio_test` or equivalent).
2. **Schema & Migration Preflight:**
   Automated Drizzle migrations (`drizzle-kit migrate`) are applied prior to test execution, verifying actual relational constraints, partial unique indices, foreign key cascades, and check constraints.
3. **Pessimistic Concurrency:**
   Tests invoke real SQL `FOR UPDATE` locks and evaluate real PostgreSQL error code `23505` (unique violation) and conditional update row counts (`returning`).
4. **pg-boss Schema Integration:**
   `startConversionQueue()` provisions pg-boss tables (`pgboss.job`, `pgboss.version`, `pgboss.archive`) directly in the PostgreSQL database.
